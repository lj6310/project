<?php
require 'My.php';
$my = new My();

//非递归

$m = 8;
$res = $my->add($m);
echo $res;

echo "<br/>";


//递归


$m = 8;
$a = 0;
$b = 1;
$res = $my->add_do($m,$a,$b);
echo $res;








?>