// pages/show/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{},
    data:{},
    page:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var openid = options.openid;
    
    this.setData({
      'user.openid': openid
    })
    var that = this
    wx.request({
      url: 'http://47.93.8.111/10/basic/web/index.php?r=user/show&openid='+openid,
      method:'GET',
      dataType:'json',
      success:function(v)
      {
        console.log(v)
        that.setData({
          data:v.data.data,
          page:v.data.page
        })
      }

    })

  },
  //预约
  is_dz:function(v)
  {

    var that = this
    var id = v.currentTarget.dataset.id
    var index = v.currentTarget.dataset.index
    var p = 'data['+index+'].is_dz'

    wx.request({
      url: 'http://47.93.8.111/10/basic/web/index.php?r=user/upd&id=' + id,
      method: 'GET',
      dataType: 'json',
      success: function (v) {

        that.setData({
          [p]: v.data
        })
      }

    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var page = this.data.page
    page--
    var openid = this.data.user.openid;
    var that = this
    wx.request({
      url: 'http://47.93.8.111/10/basic/web/index.php?r=user/show&openid=' + openid + '&page=' + page,
      method: 'GET',
      dataType: 'json',
      success: function (v) {
        console.log(v)
        that.setData({
          data: v.data.data,
          page: v.data.page
        })
      }

    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

    var page = this.data.page
    page++
    var openid = this.data.user.openid;
    var that = this
    wx.request({
      url: 'http://47.93.8.111/10/basic/web/index.php?r=user/show&openid=' + openid+'&page='+page,
      method: 'GET',
      dataType: 'json',
      success: function (v) {
        console.log(v)
        that.setData({
          data: v.data.data,
          page: v.data.page
        })
      }

    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})