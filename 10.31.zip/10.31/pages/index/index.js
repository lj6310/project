// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    appid: 'wxf25eb4921b5d321f', 
    AppSecret: '79d589cfaf56596707bdafd063b6c38a',
    user:{}
  },

  //获取个人信息
  getuser:function(v)
  {

    var that = this;
    wx.login({
      success:function(res)
      {
        var code = res.code;
        wx.request({
          url: 'https://api.weixin.qq.com/sns/jscode2session?appid='+that.data.appid+'&secret='+that.data.AppSecret+'&js_code='+code+'&grant_type=authorization_code',
          method:'GET',
          dataType:'json',
          success:function(v)
          {
            
            var openid = v.data.openid
            that.setData({
              'user.openid':openid
            })
            wx.request({
              url: 'http://47.93.8.111/10/basic/web/index.php?r=user/login&openid='+openid,
              method:'GET',
              dataType:'json',
              success:function(v)
              {
                if(v.data == '1')
                {
                  wx.navigateTo({
                    url: '/pages/show/index?openid=' + openid,
                  })
                }else if(v.data == '2')
                {
                  wx.navigateTo({
                    url: '/pages/add/index?openid='+openid,
                  })
                }
              }
            })
          }
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})