// pages/add/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var openid = options.openid;
    console.log(openid)
    this.setData({
        'user.openid':openid
    })
  },
  //获取姓名
  name:function(v)
  {
    this.setData({
      'user.name': v.detail.value
    })
  },
  //获取手机号
  name: function (v) {
    this.setData({
      'user.phone': v.detail.value
    })
  },
  //获取地址
  name: function (v) {
    this.setData({
      'user.dz': v.detail.value
    })
  },
  //添加注册
  tj:function()
  {
    var name = this.data.user.name
    var phone = this.data.user.phone
    var dz = this.data.user.dz
    var openid = this.data.user.openid
    var that = this
    wx.request({
      url: 'http://47.93.8.111/10/basic/web/index.php?r=user/add',
      data:{name:name,phone:phone,dz:dz,openid:openid},
      method:'GET',
      dataType:'json',
      success:function(v)
      {
        if (v.data == '2') {
          wx.navigateTo({
            url: '/pages/show/index?openid=' + openid,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})