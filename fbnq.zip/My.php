<?php




/**
 * 
 */
class My
{
	
	// function __construct(argument)
	// {
	// 	# code...
	// }
	function add($str)
	{
		if($str == 1)
		{
			return 0;
		}
		if($str == 2)
		{
			return 1;
		}
		echo $a = 0;
		echo " ";
		echo $b = 1;
		echo "	";
		echo $c = '';
		for ($i=3; $i <=$str ; $i++) { 
			$c = $a+$b;
			$a = $b;
			$b = $c;
			echo $c;
			echo "	";
		}
	}
	public function add_do($str,$a=0,$b=1)
	{
		if($str <= 2)
		{
			return $str-1;
		}else if($str == 3)
		{
			return $a+$b;
		}else
		{
			return $this->add_do($str-1,$b,$a+$b);
		}

	}
}










?>